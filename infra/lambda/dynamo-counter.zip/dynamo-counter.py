import json
import boto3
import os



# resource name
dynamodb = boto3.resource('dynamodb')
dynamo_table = os.environ['resume-counter-table']


# get table
counter_table = dynamodb.Table(dynamo_table)

def lambda_handler(event, context):
    response = counter_table.get_item(Key={
        'id': 'counter_id'
    })
    views=response["Item"]["views"]
    views = views + 1
    print(views)
    response = counter_table.put_item(Item={
        'id':'counter_id',
        'views': views
    })
    return views